package principal;

public class Labyrinthe {
	
	// Variables
	private int dim = 11, nbArmuresChevalier = 0, numLaby = 0, mouvFant1 = 1, mouvFant2 = 1, nbArmuresPosees = 0, nbFantomesPosees = 0;
	private Dalle[][] dalles;
	private int[] posPrincesse, posChevalier, posArmure1, posArmure2, posArmure3, posFant1, posFant2;
	private int[][] listeArmures = null, listeFantomes;
	private boolean afficheDistances = false;
	
	
	// Constructeurs
	public Labyrinthe(int dim, Dalle[][] dalles) {
		super();
		this.dim = dim;
		this.dalles = dalles;
	}
	
	public Labyrinthe(int dim) {
		super();
		this.dim = dim;
	}
	
	public Labyrinthe() {
		super();
	}
	
	
	// Getters et Setters
	public int getDim() {
		return dim;
	}
	public void setDim(int dim) {
		this.dim = dim;
	}

	public Dalle[][] getDalles() {
		return dalles;
	}
	public void setDalles(Dalle[][] dalles) {
		this.dalles = dalles;
	}

	public int[] getPosPrincesse() {
		return posPrincesse;
	}
	public void setPosPrincesse(int[] posPrincesse) {
		this.posPrincesse = posPrincesse;
	}

	public int[] getPosChevalier() {
		return posChevalier;
	}
	public void setPosChevalier(int[] posChevalier) {
		this.posChevalier = posChevalier;
	}

	public int[] getPosFant1() {
		return posFant1;
	}
	public void setPosFant1(int[] posFant1) {
		this.posFant1 = posFant1;
	}

	public int[] getPosFant2() {
		return posFant2;
	}
	public void setPosFant2(int[] posFant2) {
		this.posFant2 = posFant2;
	}
	
	public int getNbArmuresChevalier() {
		return nbArmuresChevalier;
	}

	public void setNbArmuresChevalier(int nbArmuresChevalier) {
		this.nbArmuresChevalier = nbArmuresChevalier;
	}

	public int[] getPosArmure1() {
		return posArmure1;
	}

	public void setPosArmure1(int[] posArmure1) {
		this.posArmure1 = posArmure1;
	}

	public int[] getPosArmure2() {
		return posArmure2;
	}
	public void setPosArmure2(int[] posArmure2) {
		this.posArmure2 = posArmure2;
	}

	public int[] getPosArmure3() {
		return posArmure3;
	}
	public void setPosArmure3(int[] posArmure3) {
		this.posArmure3 = posArmure3;
	}

	public int[][] getListeArmures() {
		return listeArmures;
	}
	public void setListeArmures(int[][] listeArmures) {
		this.listeArmures = listeArmures;
	}

	public boolean isAfficheDistances() {
		return afficheDistances;
	}
	public void setAfficheDistances(boolean afficheDistances) {
		this.afficheDistances = afficheDistances;
	}

	public int getNumLaby() {
		return numLaby;
	}
	public void setNumLaby(int numLaby) {
		this.numLaby = numLaby;
	}

	public int[][] getListeFantomes() {
		return listeFantomes;
	}
	public void setListeFantomes(int[][] listeFantomes) {
		this.listeFantomes = listeFantomes;
	}
	
	public int getMouvFant1() {
		return mouvFant1;
	}
	public void setMouvFant1(int mouvFant1) {
		this.mouvFant1 = mouvFant1;
	}
	
	public int getMouvFant2() {
		return mouvFant2;
	}
	public void setMouvFant2(int mouvFant2) {
		this.mouvFant2 = mouvFant2;
	}
	
	
	// Méthodes

	public void init0(){
		dalles = new Dalle[dim][dim];
		
		posChevalier = new int[] {-1, -1}; // Les éléments du jeu sont placés initialement à l'extérieur de la grille, et ne sont donc pas représentés.
		posPrincesse = new int[] {-1, -1}; 
		
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				dalles[i][j] = new Dalle(false); // On initialise toutes les cases comme des cass sans murs.
			}
		}
		
		listeArmures = new int[3][2];
		listeFantomes = new int[2][2];
	}
	
	public void init1(){
		dalles = new Dalle[dim][dim];
		
		posChevalier = new int[] {0, 9}; // On place le chevalier à l'entrée du labyrinthe.
		posPrincesse = new int[] {10, 1}; // On place la princesse à la sortie du labyrinthe.
		
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				dalles[i][j] = new Dalle(false); // On initialise toutes les cases comme des cass sans murs.
			}
		}
		
		// ----- 1ère ligne -----
		for (int i = 0; i < dim; i++) {
			dalles[0][i].setMur(true);
		}
		dalles[0][9].setMur(false); // L'entrée du labyrinthe est une case sans mur.
		
		// ----- 2ème ligne -----
		dalles[1][0].setMur(true);
		dalles[1][6].setMur(true);
		dalles[1][10].setMur(true);
		
		// ----- 3ème ligne -----
		for (int i = 0; i < dim; i++) {
			dalles[2][i].setMur(true);
		}
		dalles[2][1].setMur(false);
		dalles[2][7].setMur(false);
		
		// ----- 4ème ligne -----
		dalles[3][0].setMur(true);
		dalles[3][10].setMur(true);
		
		// ----- 5ème ligne -----
		for (int i = 0; i < dim; i++) {
			dalles[4][i].setMur(true);
		}
		dalles[4][1].setMur(false);
		dalles[4][2].setMur(false);
		dalles[4][7].setMur(false);
		dalles[4][9].setMur(false);
		
		// ----- 6ème ligne -----
		dalles[5][0].setMur(true);
		dalles[5][4].setMur(true);
		dalles[5][8].setMur(true);
		dalles[5][10].setMur(true);
		
		// ----- 7ème ligne -----
		dalles[6][0].setMur(true);
		dalles[6][4].setMur(true);
		dalles[6][8].setMur(true);
		dalles[6][10].setMur(true);
		
		// ----- 8ème ligne -----
		dalles[7][0].setMur(true);
		dalles[7][2].setMur(true);
		dalles[7][3].setMur(true);
		dalles[7][4].setMur(true);
		dalles[7][8].setMur(true);
		dalles[7][10].setMur(true);
		
		// ----- 9ème ligne -----
		dalles[8][0].setMur(true);
		dalles[8][6].setMur(true);
		dalles[8][7].setMur(true);
		dalles[8][8].setMur(true);
		dalles[8][10].setMur(true);
		
		// ----- 10ème ligne -----
		dalles[9][0].setMur(true);
		dalles[9][3].setMur(true);
		dalles[9][10].setMur(true);
		
		// ----- 11ème ligne -----
		for (int i = 0; i < dim; i++) {
			dalles[10][i].setMur(true);
		}
		dalles[10][1].setMur(false); // La sortir est une case sans mur. Cette case correspond aussi à la position de la princesse.
		
		// ----- On place les armures -----
		//dalles[1][5].setArmure(true);
		//posArmure1 = new int[] {1, 5};
		posArmure1 = initArmure();
		//dalles[6][3].setArmure(true);
		//posArmure2 = new int[] {6, 3};
		posArmure2 = initArmure();
		//dalles[7][7].setArmure(true);
		//posArmure3 = new int[] {7, 7};
		posArmure3 = initArmure();
		//listeArmures = new int[][] {posArmure1, posArmure2, posArmure3};
		
		// ----- On place les fantômes ----- 
		//dalles[8][3].setFantome(true);
		//posFant1 = new int[] {8, 3};
		posFant1 = initFantome();
		//dalles[5][7].setFantome(true);
		//posFant2 = new int[] {5, 7};
		posFant2 = initFantome();
		//listeFantomes = new int[][] {posFant1, posFant2};
		odeursFantomes();
		
		calculDistance(posPrincesse);
	}
	
	public void init2(){
		dalles = new Dalle[dim][dim];
		
		posChevalier = new int[] {0, 9}; // On place le chevalier à l'entrée du labyrinthe.
		posPrincesse = new int[] {10, 1}; // On place la princesse à la sortie du labyrinthe.
		
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				dalles[i][j] = new Dalle(false); // On initialise toutes les cases comme des cass sans murs.
			}
		}
		
		// ----- 1ère ligne -----
		for (int i = 0; i < dim; i++) {
			dalles[0][i].setMur(true);
		}
		dalles[0][9].setMur(false); // L'entrée du labyrinthe est une case sans mur.
		
		// ----- 2�me ligne -----
		dalles[1][0].setMur(true);
		dalles[1][10].setMur(true);
		
		// ----- 3�me ligne -----
		for (int i = 0; i < dim; i++) {
			dalles[2][i].setMur(true);
		}
		dalles[2][1].setMur(false);
		dalles[2][3].setMur(false);
		dalles[2][6].setMur(false);
		dalles[2][9].setMur(false);
		
		// ----- 4�me ligne -----
		dalles[3][0].setMur(true);
		dalles[3][10].setMur(true);
		
		// ----- 5�me ligne -----
		for (int i = 0; i < dim; i++) {
			dalles[4][i].setMur(true);
		}
		dalles[4][1].setMur(false);
		dalles[4][2].setMur(false);
		dalles[4][7].setMur(false);
		dalles[4][9].setMur(false);
		
		// ----- 6�me ligne -----
		dalles[5][0].setMur(true);
		dalles[5][4].setMur(true);
		dalles[5][8].setMur(true);
		dalles[5][10].setMur(true);
		
		// ----- 7�me ligne -----
		dalles[6][0].setMur(true);
		dalles[6][7].setMur(true);
		dalles[6][8].setMur(true);
		dalles[6][9].setMur(true);
		dalles[6][10].setMur(true);
		
		// ----- 8�me ligne -----
		dalles[7][0].setMur(true);
		dalles[7][2].setMur(true);
		dalles[7][3].setMur(true);
		dalles[7][4].setMur(true);
		dalles[7][8].setMur(true);
		dalles[7][10].setMur(true);
		
		// ----- 9�me ligne -----
		dalles[8][0].setMur(true);
		dalles[8][3].setMur(true);
		dalles[8][6].setMur(true);
		dalles[8][7].setMur(true);
		dalles[8][8].setMur(true);
		dalles[8][10].setMur(true);
		
		// ----- 10�me ligne -----
		dalles[9][0].setMur(true);
		dalles[9][10].setMur(true);
		
		// ----- 11�me ligne -----
		for (int i = 0; i < dim; i++) {
			dalles[10][i].setMur(true);
		}
		dalles[10][1].setMur(false); // La sortir est une case sans mur. Cette case correspond aussi à la position de la princesse.
		
		// ----- On place les armures ----- 
		//dalles[2][3].setArmure(true);
		//posArmure1 = new int[] {2, 3};
		posArmure1 = initArmure();
		//dalles[5][9].setArmure(true);
		//posArmure2 = new int[] {5, 9};
		posArmure2 = initArmure();
		//dalles[8][9].setArmure(true);
		//posArmure3 = new int[] {8,9};
		posArmure3 = initArmure();
		listeArmures = new int[][] {posArmure1, posArmure2, posArmure3};
		
		// ----- On place les fant�mes ----- 
		//dalles[3][4].setFantome(true);
		//posFant1 = new int[] {3, 4};
		posFant1 = initFantome();
		//dalles[7][5].setFantome(true);
		//dalles[7][5].setOdeur(true);
		//posFant2 = new int[] {7, 5};
		posFant2 = initFantome();
		//listeFantomes = new int[][] {posFant1, posFant2};
		odeursFantomes();
		
		calculDistance(posPrincesse);
	}
	
	public int[] initArmure(){
		int x = -1;
		int y = -1;
		int[] pos = {x, y};
		boolean test = false;
		while(!test){
			test = true;
			
			// On tire au hasard une case dans le labyrinthe
			x = (int) (1 + Math.random() * (dim - 2));
			y = (int) (1 + Math.random() * (dim - 2));
			
			// On vérifie si cettte case ne correspond pas à un mur ou a une autre armure.
			Dalle dalleTest = dalles[x][y];
			if(dalleTest.isMur() || dalleTest.isArmure()){
				test = false;
			}
			/*
			for (int i = 0; i < listeArmures.length; i++) {
				if(listeArmures[i] != null){
					calculDistance(listeArmures[i]);
					if(dalleTest.getDistance() < 4)test=false;
				}
			}
			*/
			
		}
		
		pos[0] = x;
		pos[1] = y;
		dalles[x][y].setArmure(true); // La case sur laquelle on pose une armure possède alors une armure.
		listeArmures[nbArmuresPosees] = pos;
		nbArmuresPosees++;
		
		return pos;
	}

	public int[] initFantome(){
		int x = -1;
		int y = -1;
		int[] pos = {x, y};
		boolean test = false;
		// On ne s'arrête que lorsqu'on a trouvé une case qui peut acceuillir un fantôme.
		while(!test){ 
			test = true;
			
			// On tire au hasard une case dans le labyrinthe
			x = (int) (1 + Math.random() * (dim - 2));
			y = (int) (1 + Math.random() * (dim - 2));
			
			// On doit vérifier si cettte case ne correspond pas à un mur ou a un autre fantôme.
			Dalle dalleTest = dalles[x][y]; 
			// Le fantôme ne peut pas être à moins de 3 cases du chevalier lors de l'initialisation.
			calculDistance(posChevalier); 
			if(dalleTest.isMur() || dalleTest.isFantome() || dalleTest.getDistance() < 3)test = false;
		}
		
		pos[0] = x;
		pos[1] = y;
		dalles[x][y].setFantome(true); 
		listeFantomes[nbFantomesPosees] = pos;
		nbFantomesPosees++;
		
		return pos;
	}
	
	public boolean estDedans(int[] pos){ // Vérifie si une position donnée apartient bien à notre labyrinthe.
		if(pos[0] >= 0 && pos[0] < dim && pos[1] >= 0 && pos[1] < dim){
			return true;
		}
		return false;
	}
	
	public boolean estArrive(){ // Renvoie true si le chevalier à trouvé la princesse et possêde l'ensemble des pièces d'armures.
		return posChevalier[0] == posPrincesse[0] && posChevalier[1] == posPrincesse[1] && nbArmuresChevalier == listeArmures.length;
	}
	
	public void resetDistances(){
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				dalles[i][j].setDistance(-1); // On initialise toutes les cases comme des cass sans murs.
			}
		}
	}
	
	public void calculDistance(int[] pos){
		resetDistances();
		dalles[pos[0]][pos[1]].setDistance(0); // La distance de la case d'origine à elle même est 0.
		
		boolean fini = false;
		while(!fini){
			fini = true;
			for (int i = 0; i < dim; i++) {
				for (int j = 0; j < dim; j++) {
					if(!dalles[i][j].isMur() && dalles[i][j].getDistance() != -1 && !dalles[i][j].isFantome()){
						for (int k = -1; k < 2; k++) {
							for (int l = -1; l < 2; l++) {
								int[] posTest = {i+k, j+l};
								if(estDedans(posTest) && !dalles[i+k][j+l].isMur() && !dalles[i+k][j+l].isFantome()){
									if(dalles[i+k][j+l].getDistance() > dalles[i][j].getDistance() + 1 || dalles[i+k][j+l].getDistance() == -1){
										dalles[i+k][j+l].setDistance(dalles[i][j].getDistance() + 1);
										fini = false;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	public void resetOdeur(){
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				dalles[i][j].setOdeur(false); // On initialise toutes les cases comme des cass sans murs.
			}
		}
	}
	
	public void odeursFantomes(){
		for (int f = 0; f < listeFantomes.length; f++) {
			int x = listeFantomes[f][0], y = listeFantomes[f][1]; // Coordonnées du fantômes à qui ont attribu une odeur.
			for (int i = -1; i < 2; i++) {
				for (int j = -1; j < 2; j++) {
					int[] posTest = {x+i, y+j};
					if(estDedans(posTest) && !dalles[x+i][y+j].isMur()){ // On cionsidère que les murs ne peuvent avoir une odeur.
						dalles[x+i][y+j].setOdeur(true);
					}
				}
			}
		}
	}
	
	public void avanceChevalierAuto(){ // Fait avancer le chevalier d'une case vers sa destination (l'origine de calculDistance).
		int x = posChevalier[0], y = posChevalier[1];
		for (int i = -1; i < 2; i++) {
			for (int j = -1; j < 2; j++) {
				int[] posTest = {x+i, y+j};
				if(estDedans(posTest) && !dalles[x+i][y+j].isMur() && !dalles[x+i][y+j].isFantome() && !dalles[x+i][y+j].isOdeur() && dalles[x+i][y+j].getDistance() == dalles[x][y].getDistance()-1){
					posChevalier = posTest;
					//deplaceFantomes();
				}
			}
		}
		if(x == posChevalier[0] && y == posChevalier[1]){ // Si le chevalier n'a pas bougé, on l'autorise à se déplacer sur une case où il y a une odeur (mais pas de fantôme) et si la ditance à l'objectif ne change pas.
			for (int i = -1; i < 2; i++) {
				for (int j = -1; j < 2; j++) {
					int[] posTest = {x+i, y+j};
					if(estDedans(posTest) && !dalles[x+i][y+j].isMur() && !dalles[x+i][y+j].isFantome() && (dalles[x+i][y+j].getDistance() == dalles[x][y].getDistance()-1 || dalles[x+i][y+j].getDistance() == dalles[x][y].getDistance())){
						posChevalier = posTest;
						//deplaceFantomes();
					}
				}
			}
		}
		deplaceFantomes();
		x = posChevalier[0];
		y = posChevalier[1];
		for (int k = 0; k < listeArmures.length; k++) {
			if(posChevalier[0] == listeArmures[k][0] && posChevalier[1] == listeArmures[k][1] && dalles[x][y].isArmure()){ // Si le chevalier s'est déplacé sur une pièce d'armure qui n'a pas encore été rammassée.
				nbArmuresChevalier++; // Le nombre de pièce d'armure que possède le chevalier augmente.
				dalles[x][y].setArmure(false); // On retire l'armure du jeu.
			}
		}
	}
	
	public void avanceChevalierAuto(int i, int j){ // Fait avancer le chevalier de i cases dans la verticale et j cases dans l'horizontale.
		
		int x = posChevalier[0], y = posChevalier[1];
		int[] posTest = {x+i, y+j};
		if(estDedans(posTest) && dalles[x+i][y+j].isMur()){
			javax.swing.JOptionPane.showMessageDialog(null,"Tu as beau être un chevalier beau et fort, tu ne peux pas traverser les murs, dommage.");
		}
		if(estDedans(posTest) && !dalles[x+i][y+j].isMur() && !dalles[x+i][y+j].isFantome() && !(posEgales(posTest, posPrincesse) && nbArmuresChevalier < listeArmures.length)){
			posChevalier = posTest;
			deplaceFantomes();
		}
		if(estDedans(posTest) && dalles[x+i][y+j].isFantome()){
			javax.swing.JOptionPane.showMessageDialog(null,"Ta rencontre malheureuse avec un fantôme t'envoie dans l'au-delà. Cunégonde va devoir encore attendre...");
			reset();
		}
		if(posEgales(posTest, posPrincesse) && nbArmuresChevalier < listeArmures.length){
			javax.swing.JOptionPane.showMessageDialog(null,"C'est bien, tu as trouvé la sortie du labyrinthe et tu te retrouve face au dragon. \n Malheureusement, ton armure n'est pas complête." +
					" Si tu ne veux avoir une chance de ne pas finir grillé, fais vite demi-tour pour chercher les pièces manquantes !");
		}
		x = posChevalier[0];
		y = posChevalier[1];
		for (int k = 0; k < listeArmures.length; k++) {
			if(posChevalier[0] == listeArmures[k][0] && posChevalier[1] == listeArmures[k][1] && dalles[x][y].isArmure()){ // Si le chevalier s'est d�plac� sur une pi�ce d'armure qui n'a pas encore �t� rammass�.
				nbArmuresChevalier++; // Le nombre de pi�ce d'armure que poss�de le chevalier augmente.
				dalles[x][y].setArmure(false); // On retire l'armure du jeu.
			}
		}
		
	}
	
	public void goArmures(){
		for (int k = 0; k < listeArmures.length; k++) {
			calculDistance(listeArmures[k]);
			while(dalles[listeArmures[k][0]][listeArmures[k][1]].isArmure()){ // Tant que armure 1 est toujours sur sa case (i.e. le chevalier ne l'a pas encore ramassé), le chevalier avance vers l'armure.
				avanceChevalierAuto();
			}
		}
	}
	
	public void reset(){
		listeArmures = new int[3][2];
		nbArmuresChevalier = 0;
		nbArmuresPosees = 0;
		
		listeFantomes = new int[2][2];
		nbFantomesPosees = 0;
		
		if(numLaby == 1){
			init1();
		}else{
			init2();
		}
	}
	
	public boolean estEnceinte(int[] pos){
		return pos[0] == 0 || pos[0] == (dim -1) || pos[1] == 0 || pos[1] == (dim -1);
	}
	
	public void deplaceFantomes(){ // Le fantôme 1 se déplace à l'horizontale et le fantôme 2 se déplace à la verticale.
		resetOdeur();
		
		dalles[posFant1[0]][posFant1[1]].setFantome(false); // Le fantôme part de sa case.
		int newColF1 = posFant1[1] + mouvFant1;
		if(newColF1 == 0){
			newColF1=2;
			mouvFant1 = -mouvFant1;
		}
		if(newColF1 == dim-1){
			newColF1=dim-3;
			mouvFant1 = -mouvFant1;
		}
		posFant1[1] = newColF1;
		dalles[posFant1[0]][posFant1[1]].setFantome(true); // Le fantôme arrive sur une nouvelle case.
		
		dalles[posFant2[0]][posFant2[1]].setFantome(false);
		int newLigF2 = posFant2[0] + mouvFant2;
		if(newLigF2 == 0){
			newLigF2=2;
			mouvFant2 = -mouvFant2;
		}
		if(newLigF2 == dim-1){
			newLigF2=dim-3;
			mouvFant2 = -mouvFant2;
		}
		posFant2[0]=newLigF2;
		dalles[posFant2[0]][posFant2[1]].setFantome(true);
		
		odeursFantomes();
	}
	
	public int[] vectDistances(int[] pos){
		int[][] vectPos = {posChevalier, posArmure1, posArmure2, posArmure3, posPrincesse};
		int[] vectDistances = new int[5]; // Ce vecteur contiendra dans l'ordre la distance de pos au chevalier, à l'armure 1, à l'armure 2, à l'armure 3 et à la princesse.
		for (int i = 0; i < vectPos.length; i++) {
			calculDistance(vectPos[i]);
			vectDistances[i] = dalles[pos[0]][pos[1]].getDistance();
		}
		return vectDistances;
	}
	
	public boolean posEgales(int[] pos1, int[] pos2){ // Renvoie vrai si deux position correspondent à la même case (i.e. si les vecteurs des coordonnées sont égaux). 
		return pos1[0] == pos2[0] && pos1[1] == pos2[1];
	}
	
	public int[][] armuresRestantes(){
		int[][] armuresRestantes = new int[3][2];
		
		for (int i = 0; i < listeArmures.length; i++) {
			int x = listeArmures[i][0];
			int y = listeArmures[i][1];
			if(dalles[x][y].isArmure()){
				armuresRestantes[i] = listeArmures[i];
			}else{
				armuresRestantes[i] = null;
			}
		}
		
		return armuresRestantes;
	}
	
	public int[] nextArmure(){ // Renvoie la position de l'armure la plus proche du chevalier.
		int[] res = new int[2];
		//int [][] armuresRestantes = armuresRestantes();
		int[] distances = new int[listeArmures.length];
		
		calculDistance(posChevalier);
		for (int i = 0; i < listeArmures.length; i++) {
			int x = listeArmures[i][0];
			int y = listeArmures[i][1];
			if(dalles[x][y].isArmure()){
				distances[i] = dalles[x][y].getDistance();
			}else{
				distances[i] = dim + 1;
			}
		}
		int indMin = min(distances);
		res = listeArmures[indMin];
		return res;
	}
	
	public int min(int[] liste){ // Renvoie l'indice correspondant au minimum d'une liste
		int ind = 0;
		int min = liste[0];
		
		for (int i = 0; i < liste.length; i++) {
			if(liste[i] < min){
				min = liste[i];
				ind = i;
			}
		}
		
		return ind;	
	}
	
	
}
