package principal;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

// Cette classe permet d'afficher la grille du labyrinthe. Elle est utilisée dans la classe qui permet d'afficher la fenêtre de jeu, LabyrintheFenetre.
public class Grille extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Labyrinthe laby;
	
	public Grille(Labyrinthe laby) {
		super();
		this.laby = laby;
	}

	private static final int TAILLE_CASE = 50, DEC_GAUCHE = 10, DEC_HAUT = 10;
	
	Image[] listeImages = images();
	
	public Image[] images() { // Renvoie un vecteur d'image pour les stocker, afin de ne pas avoir à aller chercher les images à chaque fois.
		Image[] images = new Image[6];
		
		try{
			images[0] = ImageIO.read(new File("Chevalier.png"));
		}catch(IOException e){
			e.printStackTrace();
		}
		
		for (int i = 1; i < 4; i++) {
			String armure = "Armure" + (i) + ".jpg";
			try{
				images[i] = ImageIO.read(new File(armure));
			}catch(IOException e){
				e.printStackTrace();
			}
		}
		
		try{
			images[4] = ImageIO.read(new File("Fantome.png"));
		}catch(IOException e){
			e.printStackTrace();
		}
		
		try{
			images[5] = ImageIO.read(new File("Princesse2.png"));
		}catch(IOException e){
			e.printStackTrace();
		}
		
		return images;
	}
	
	public void paint(Graphics g){
		
		int dim = laby.getDim();
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				
				int x = DEC_GAUCHE + (j + 1) * TAILLE_CASE;
				int y = DEC_HAUT + (i + 1)* TAILLE_CASE;
				int posPrincesseX = this.laby.getPosPrincesse()[0];
				int posPrincesseY = this.laby.getPosPrincesse()[1];
				int posChevalierX = this.laby.getPosChevalier()[0];
				int posChevalierY = this.laby.getPosChevalier()[1];
				
				if(this.laby.getDalles()[i][j].isMur()){
					g.setColor(Color.BLACK);
					g.fillRect(x, y, TAILLE_CASE, TAILLE_CASE);
				}
				else{
					g.setColor(Color.WHITE);
					g.fillRect(x, y, TAILLE_CASE, TAILLE_CASE); // On met du blanc sur la case, pour "effacer".
					
					g.setColor(Color.LIGHT_GRAY);
					g.drawRect(x, y, TAILLE_CASE, TAILLE_CASE);
				}
				
				if(this.laby.getDalles()[i][j].isArmure()){
					g.setColor(Color.WHITE);
					g.fillRect(x, y, TAILLE_CASE, TAILLE_CASE);
					
					for (int k = 0; k < laby.getListeArmures().length; k++) {
						if(laby.getListeArmures()[k][0] == i && laby.getListeArmures()[k][1] == j){
							g.drawImage(listeImages[k+1], x, y, TAILLE_CASE - 2, TAILLE_CASE - 2, this);
						}
					}
					
					g.setColor(Color.LIGHT_GRAY);
					g.drawRect(x, y, TAILLE_CASE, TAILLE_CASE);
				}
				
				// Si on décide de faire apparaître les odeurs.
				/*
				if(this.laby.getDalles()[i][j].isOdeur() && !this.laby.getDalles()[i][j].isMur() ){
					g.setColor(Color.WHITE);
					g.fillRect(x, y, TAILLE_CASE, TAILLE_CASE);
					
					g.setColor(Color.GREEN);
					g.fillRect(x, y, TAILLE_CASE, TAILLE_CASE);
				}
				*/
				
				if(this.laby.getDalles()[i][j].isFantome() && !this.laby.getDalles()[i][j].isMur() ){
					g.setColor(Color.WHITE);
					g.fillRect(x, y, TAILLE_CASE, TAILLE_CASE);
					
					g.drawImage(listeImages[4], x, y, TAILLE_CASE - 2, TAILLE_CASE - 2, this);
					
					g.setColor(Color.LIGHT_GRAY);
					g.drawRect(x, y, TAILLE_CASE, TAILLE_CASE);
				}
				
				if(posPrincesseX == i && posPrincesseY == j){
					g.setColor(Color.WHITE);
					g.fillRect(x, y, TAILLE_CASE, TAILLE_CASE);
					
					g.drawImage(listeImages[5], DEC_HAUT + 2 + (posPrincesseY + 1)* TAILLE_CASE, DEC_GAUCHE + 2 + (posPrincesseX + 1)* TAILLE_CASE, TAILLE_CASE - 2, TAILLE_CASE - 2, this);
					
					g.setColor(Color.LIGHT_GRAY);
					g.drawRect(x, y, TAILLE_CASE, TAILLE_CASE);
				}
				
				if(posChevalierX == i && posChevalierY== j){
					g.setColor(Color.WHITE);
					g.fillRect(x, y, TAILLE_CASE, TAILLE_CASE);
					
					g.drawImage(listeImages[0], DEC_HAUT + 2 + (posChevalierY + 1)* TAILLE_CASE, DEC_GAUCHE + 2 + (posChevalierX + 1)* TAILLE_CASE, TAILLE_CASE - 2, TAILLE_CASE - 2, this);
					
					g.setColor(Color.LIGHT_GRAY);
					g.drawRect(x, y, TAILLE_CASE, TAILLE_CASE);
				}
				
				if(laby.isAfficheDistances()){
					g.setColor(Color.BLACK);
					g.drawString("" + this.laby.getDalles()[i][j].getDistance(), x + 10, y + 20);
				}
			}
		}
	}
	
}
