package principal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.Timer;

public class LabyrintheFenetre extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Labyrinthe laby = new Labyrinthe();
	
	private Grille grille = new Grille(laby);
	private JButton boutonAuto = new JButton("Mode automatique");
	private JLabel boutonManu = new JLabel("Mode manuel :");
	private JButton NO = new JButton("NO");
	private JButton N = new JButton("N");
	private JButton NE = new JButton("NE");
	private JButton O = new JButton("O");
	private JButton E = new JButton("E");
	private JButton SO = new JButton("SO");
	private JButton S = new JButton("S");
	private JButton SE = new JButton("SE");
	private JButton Attendre = new JButton("Attendre");
	private JPanel container = new JPanel();
	private JLabel nbArmure = new JLabel("Vous avez récupéré 0 pièces d'armure.");
	private JCheckBox afficheDistances = new JCheckBox("Afficher les distances");
	private JComboBox<String> numLabyCB = new JComboBox<String>(); // Choisir le labyrinthe avec une CheckBox ?
	private JLabel numLaby = new JLabel("Choix du labyrinthe :");
	private JLabel numLabySelect = new JLabel("Vous avez choisi le labyrinthe numéro 1");
	
	// private boolean modeManu = false, modeAuto = false;
	
	public LabyrintheFenetre(){
		super("LabyrintheFenetre");
		
		// Initialisation du labyrinthe
		laby.init0();
		
		// Pour voir le chevalier bouger tour à tour dans le labyrinthe, initialisez avec un labyrinthe (1 ou 2 en paramètre), puis à la fin de cette méthode, appelez goAuto()
		//laby.setNumLaby(2);
		//laby.reset();
		
		// Propriétés de la fenêtre
		this.setTitle("Le labyrinthe hanté"); // Définit un titre pour la fenêtre
		this.setSize(1000, 1000); // Définit la taille de la fenêtre.
		this.setResizable(true); // Empêche (ou autorise) le redimensionnement de la fenêtre.
		this.setLocationRelativeTo(null); // Permet de positionner la fenêtre au centre.
		this.setAlwaysOnTop(false); // Laisse (ou pas) la fenêtre au premier plan.
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Lorsqu'on ferme la fenêtre, l'exécution du programme s'arrête.
		
		container.setBackground(Color.WHITE);
		container.setLayout(new BorderLayout());
		container.add(grille, BorderLayout.CENTER);
		
		numLabyCB.addItem("Labyrinthe 1");
		numLabyCB.addItem("Labyrinthe 2");
		numLabyCB.addActionListener(this);
		
		//boutonAuto.addActionListener(new BoutonAutoListener());
		
		boutonAuto.addActionListener(new BoutonAutoListener());
		afficheDistances.addActionListener(this);
		
		GridLayout glNorth = new GridLayout(3,2);
		glNorth.setHgap(5);
		glNorth.setVgap(5);
		
		JPanel north = new JPanel();
		north.setLayout(glNorth);
		north.add(numLaby);
		north.add(numLabyCB);
		north.add(nbArmure);
		north.add(afficheDistances);
		north.add(boutonAuto);
		north.add(boutonManu);
		container.add(north, BorderLayout.NORTH);
		
		GridLayout gl = new GridLayout(3,3);
		gl.setHgap(5);
		gl.setVgap(5);
		
		JPanel direction = new JPanel();
		direction.setLayout(gl);
		Dimension dim = new Dimension(70,70);
		NO.addActionListener(this);
		NO.setPreferredSize(dim);
		N.addActionListener(this);
		N.setPreferredSize(dim);
		NE.addActionListener(this);
		NE.setPreferredSize(dim);
		O.addActionListener(this);
		O.setPreferredSize(dim);
		Attendre.addActionListener(this);
		Attendre.setPreferredSize(dim);
		E.addActionListener(this);
		E.setPreferredSize(dim);
		SO.addActionListener(this);
		SO.setPreferredSize(dim);
		S.addActionListener(this);
		S.setPreferredSize(dim);
		SE.addActionListener(this);
		SE.setPreferredSize(dim);
		direction.add(NO);
		direction.add(N);
		direction.add(NE);
		direction.add(O);
		direction.add(Attendre);
		direction.add(E);
		direction.add(SO);
		direction.add(S);
		direction.add(SE);
		
		JPanel east = new JPanel();
		east.add(direction);
		container.add(east, BorderLayout.EAST);
		
		this.setContentPane(container);
		this.setVisible(true);
		
		javax.swing.JOptionPane.showMessageDialog(null,
				"Bienvenu preux chevalier ! \n" +
				"Ta princesse se trouve à la sortie de ce labyrinthe, tu dois aller la délivrer ! \n" +
				"Mais prends garde, un vil dragon dénommé Flamme d'Udùn (ou Flammedoudoune, on ne sait plus très bien) la garde prisonnière à tout prix ! \n" +
				"Pour réussir à le vaincre, tu dois récupérer les différentes pièces d'armure éparpillées dans le labyrinthe ! \n" +
				"Fais également attention aux fantômes qui rôdent ! Espérons que cette princesse Cunégonde vaille la peine d'affronter une mort certaine !");
		
		javax.swing.JOptionPane.showMessageDialog(null,"Avant de commencer, choisis une version du labyrinthe.");
		
		//goAuto(); // Activer cette ligne pour voir le chevalier se déplacer seul.
	}
	
	
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == numLabyCB){
			laby.setNumLaby(numLabyCB.getSelectedIndex() + 1);
			laby.reset();
		}
		numLabySelect.setText("Vous avez choisi le labyrinthe numéro " + this.laby.getNumLaby());
		
		if(arg0.getSource() == afficheDistances){
			if(afficheDistances.isSelected()){
				laby.setAfficheDistances(true);
			}else{
				laby.setAfficheDistances(false);
			}
		}
		
		if(laby.getNumLaby() == 0){
			javax.swing.JOptionPane.showMessageDialog(null,"Avant de commencer, choisis une version du labyrinthe.");
		}else{
			if(arg0.getSource() == NO)laby.avanceChevalierAuto(-1, -1);
			if(arg0.getSource() == N)laby.avanceChevalierAuto(-1, 0);
			if(arg0.getSource() == NE)laby.avanceChevalierAuto(-1, 1);
			if(arg0.getSource() == O)laby.avanceChevalierAuto(0, -1);
			if(arg0.getSource() == Attendre)laby.avanceChevalierAuto(0, 0);
			if(arg0.getSource() == E)laby.avanceChevalierAuto(0, 1);
			if(arg0.getSource() == SO)laby.avanceChevalierAuto(1, -1);
			if(arg0.getSource() == S)laby.avanceChevalierAuto(1, 0);
			if(arg0.getSource() == SE)laby.avanceChevalierAuto(1, 1);
			
			if(arg0.getSource() == numLabyCB)laby.setNumLaby(numLabyCB.getSelectedIndex()+1);
			
			nbArmure.setText("Vous avez récupéré " + this.laby.getNbArmuresChevalier() + " pièces d'armure.");
			
			numLabySelect.setText("Vous avez choisi le labyrinthe numéro " + this.laby.getNumLaby());
			
			if(laby.estArrive()){
				grille.repaint();
				fin1();
				nbArmure.setText("Vous avez récupéré " + this.laby.getNbArmuresChevalier() + " pièces d'armure.");
			}
			
			grille.repaint();
		}	
	}
	
	private void goAuto(){
		
		// Le chevalier récupère les armures une par une, en allant à chaque fois vers celle qui est la plus proche de lui.
		while(laby.getNbArmuresChevalier() < 3){
			int[] nextArmure = laby.nextArmure(); // La position de l'armure la plus proche.
			// Tant que l'armure la plus proche est toujours sur sa case (i.e. le chevalier ne l'a pas encore ramassé), le chevalier avance vers l'armure.
			while(laby.getDalles()[nextArmure[0]][nextArmure[1]].isArmure()){ 
				laby.avanceChevalierAuto();
				laby.calculDistance(nextArmure);
				nbArmure.setText("Vous avez récupéré " + this.laby.getNbArmuresChevalier() + " pièces d'armure.");
				grille.repaint();
				try{
					Thread.sleep(300);
				} catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		}
		
		// Une fois l'ensemble des pièces d'armure récoltées, le chevalier doit rejoindre la princesse.
		laby.calculDistance(laby.getPosPrincesse());
		while(!laby.estArrive()){
			laby.avanceChevalierAuto();
			laby.calculDistance(laby.getPosPrincesse());
			grille.repaint();
			try{
				Thread.sleep(300);
			} catch(InterruptedException e){
				e.printStackTrace();
			}
		}
		
		fin1();
		grille.repaint();
	}
	
	public void fin1(){
		javax.swing.JOptionPane.showMessageDialog(null, "Bravo chevalier ! Maintenant que ton armure est complête, va vaincre le vil Flammedoudoune qui garde précieusement ta bien aimé !");
		
		try{
			Thread.sleep(1000);
		} catch(InterruptedException e){
			e.printStackTrace();
		}
		javax.swing.JOptionPane.showMessageDialog(null, "Le chevalier se batta cœur et âme contre le grand Flamme d'Udùn, et ayant appris des erreurs de son mentor - le bien connu Gandalf le Gris -, il réussi finalement à le vaincre."
				+ "\nLa belle Cunégonde ainsi délivrée, le chevalier se rendit compte qu'il fallait désormais retourner dans le labyrinthe, l'unique sortie étant au même endroit que l'entrée. Y arriva t-il ?");
		javax.swing.JOptionPane.showMessageDialog(null, "Le niveau suivant est en cours de développement. Cliquez sur OK pour rejouer.");
		laby.reset();
	}
	
	class BoutonAutoListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			if(laby.getNumLaby() == 0){
				javax.swing.JOptionPane.showMessageDialog(null,"Avant de commencer, choisis une version du labyrinthe.");
			}else{
				goAuto();
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
