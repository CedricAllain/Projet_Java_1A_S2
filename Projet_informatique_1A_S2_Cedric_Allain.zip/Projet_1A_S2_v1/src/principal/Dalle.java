package principal;

// Cette classe défini l'élément de base d'un labyrinthe, à savoir une dalle.
public class Dalle {

	// ----- Variables ----- 
	private boolean mur = false, armure = false, fantome = false, visite = false, odeur = false;
	private int distance = -1;

	// ----- Constructeurs ----- 
	public Dalle() {
		super();
	}
	
	public Dalle(boolean mur) {
		super();
		this.mur = mur;
	}

	public Dalle(boolean mur, boolean armure) {
		super();
		this.mur = mur;
		this.armure = armure;
	}

	// ----- Getters et Setters ----- 
	public boolean isMur() {
		return mur;
	}
	public void setMur(boolean mur) {
		this.mur = mur;
	}

	public boolean isArmure() {
		return armure;
	}
	public void setArmure(boolean armure) {
		this.armure = armure;
	}

	public boolean isVisite() {
		return visite;
	}
	public void setVisite(boolean visite) {
		this.visite = visite;
	}

	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}

	public boolean isFantome() {
		return fantome;
	}

	public void setFantome(boolean fantome) {
		this.fantome = fantome;
	}

	public boolean isOdeur() {
		return odeur;
	}

	public void setOdeur(boolean odeur) {
		this.odeur = odeur;
	}
	
	
	
	
}
